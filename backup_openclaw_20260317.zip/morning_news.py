import urllib.request,datetime,sys,re,json,time
sys.stdout.reconfigure(encoding='utf-8')

last_record_file = 'C:\\Users\\Administrator\\.openclaw\\workspace\\memory\\openclaw_news.json'

def load_last_record():
    try:
        with open(last_record_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {'version': '', 'date': '', 'changes': []}

def save_last_record(data):
    try:
        import os
        os.makedirs(os.path.dirname(last_record_file), exist_ok=True)
        with open(last_record_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except:
        pass

# 获取江门天气 (多备用方案)
w = '获取失败'
weather_source = ''

# 方案1: wttr.in
try:
    import ssl
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    w = urllib.request.urlopen('https://wttr.in/Jiangmen?format=%c%t', timeout=5, context=ctx).read().decode()
    weather_source = 'wttr'
except:
    pass

# 方案2: Open-Meteo
if weather_source == '':
    try:
        import urllib.parse
        url = 'https://api.open-meteo.com/v1/forecast?latitude=22.58&longitude=113.08&current=temperature_2m,relative_humidity_2m,weather_code'
        data = json.loads(urllib.request.urlopen(url, timeout=5).read().decode())
        temp = data['current']['temperature_2m']
        hum = data['current']['relative_humidity_2m']
        code = data['current']['weather_code']
        # 天气码映射
        code_map = {0: '☀️', 1: '🌤️', 2: '⛅️', 3: '☁️', 45: '🌫️', 48: '🌫️', 51: '🌧️', 61: '🌧️', 71: '🌨️', 80: '🌧️', 95: '⛈️'}
        icon = code_map.get(code, '🌤️')
        w = f'{icon} {temp}°C {hum}%'
        weather_source = 'Open-Meteo'
    except Exception as e:
        pass

# 方案3: 腾讯天气API (需要认证，留作备用)
if weather_source == '':
    try:
        import json
        url = 'https://api.qweather.com/v7/weather/now?location=101280806&key=9e89aa6cbd9cd994c9252f2124dc33'
        data = json.loads(urllib.request.urlopen(url, timeout=5).read().decode())
        if data.get('code') == '200':
            w = f"{data['now']['text']} {data['now']['temp']}°C"
            weather_source = '腾讯'
    except:
        pass

# 获取红餐网外卖资讯
news = '获取中...'
try:
    req = urllib.request.Request('https://www.canyin88.com/kuaixun/', headers={'User-Agent': 'Mozilla/5.0'})
    html = urllib.request.urlopen(req, timeout=5).read().decode('utf-8', errors='ignore')
    texts = re.findall(r'<p>([^<]{10,60})</p>', html)
    titles = [t.strip() for t in texts if '编辑' not in t and '作者' not in t and '关注' not in t and '红餐' not in t][:5]
    if titles:
        news = '\n'.join([f'{i+1}. {t[:50]}' for i,t in enumerate(titles)])
    else:
        news = '暂无资讯'
except Exception as e:
    news = f'获取失败'

# 获取OpenClaw最新资讯（带缓存）
oc_news = ''
oc_update = ''
version_name = ''
version_date = ''
last_rec = load_last_record()  # 预先加载缓存

try:
    req = urllib.request.Request('https://api.github.com/repos/openclaw/openclaw/releases/latest', 
                                  headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/vnd.github+json'})
    with urllib.request.urlopen(req, timeout=10) as response:
        data = json.loads(response.read().decode())
        version_name = data.get('tag_name', 'Unknown')
        version_date = data.get('published_at', '')[:10]
        body = data.get('body', '')
        lines = [l.strip().lstrip('* ').lstrip('- ') for l in body.split('\n') if l.startswith('* ') or l.startswith('- ')]
        key_changes = []
        for l in lines:
            match = re.match(r'(.+?) by @(\w+)', l)
            if match:
                key_changes.append(match.group(1)[:60])
        key_changes = key_changes[:8]
        if key_changes:
            # 翻译成中文
            cn_map = {
                'fix(': '修复:',
                'fix:': '修复:',
                'feat(': '新增:',
                'feat:': '新增:',
                'docs:': '文档:',
                'test:': '测试:',
                'refactor:': '重构:',
                'perf(': '性能:',
                'perf:': '性能:',
                'security(': '安全:',
                'security:': '安全:',
                'Updated': '更新',
                'compaction': '会话压缩',
                'telegram': 'Telegram',
                'Discord': 'Discord',
                'gateway': '网关',
                'session': '会话',
                'default model': '默认模型',
                'CLI': '命令行',
                'thinking': '思考',
                'agents': '代理',
                'Anthropic': 'Anthropic',
                'replay': '重放',
                'Android': '安卓',
                'iOS': 'iOS',
                'Docker': 'Docker',
                'macOS': 'macOS',
                'Windows': 'Windows',
                'Slack': 'Slack',
                'UI': '界面',
                'config': '配置',
                'browser': '浏览器',
                'feishu': '飞书',
            }
            cn_changes = []
            for c in key_changes:
                cn = c
                for en, cn_txt in cn_map.items():
                    cn = cn.replace(en, cn_txt)
                cn_changes.append(cn)
            oc_news = '\n'.join([f'• {c}' for c in cn_changes])
        
        # 保存到缓存
        save_last_record({'version': version_name, 'date': version_date, 'changes': key_changes})
        
        # 检查新版本
        if last_rec.get('version') != version_name:
            oc_update = f'🆕 新版本: {version_name} ({version_date})'
        else:
            oc_update = f'版本: {version_name} ({version_date})'
            
except Exception as e:
    err_msg = str(e)
    if 'rate limit' in err_msg.lower() or '403' in err_msg:
        # 限流时使用缓存
        if last_rec.get('version'):
            version_name = last_rec.get('version', '')
            version_date = last_rec.get('date', '')
            cached_changes = last_rec.get('changes', [])
            if cached_changes:
                oc_news = '\n'.join([f'• {c}' for c in cached_changes[:8]])
            oc_update = f'版本: {version_name} ({version_date}) [缓存]'
        else:
            oc_news = '获取失败: API受限'
    else:
        oc_news = f'获取失败: {err_msg[:30]}'

oc_tips = '''【状态查看】
/status - 查看当前会话状态和用量
/reasoning - 开启/关闭思考过程显示

【快捷操作】
- 发链接自动提取网页内容
- 发文件自动分析文件内容
- 发截图可直接分析图片

【会话管理】
sessions_list - 查看所有会话
sessions_history - 查看历史消息

【技能系统】
find-skills - 查找可用技能
描述需求 - 自动匹配合适技能'''

ai_tips = '''【提问技巧】
1. 明确角色 - "你是一名10年经验的厨师"比"帮我"更有效
2. 说明背景 - 给出具体情况，答案更精准
3. 分步提问 - 复杂问题拆成多个简单问题

【回答优化】
1. 给示例 - "像这样写: xxx"
2. 指定格式 - "用表格展示"、"列点说明"
3. 追问补充 - "展开说说"、"举具体例子"

【高效使用】
1. 重复失败时换种问法
2. 善用记忆功能记住重要信息
3. 重要信息及时保存到文件'''

msg = f'''【每日晨报】{datetime.datetime.now().strftime('%Y年%m月%d日 %H:%M')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌤️ 江门天气：{w}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【外卖餐饮资讯】

{news}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【OpenClaw最新更新】

{oc_update}

{oc_news}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【OpenClaw使用技巧】

{oc_tips}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【AI高效使用技巧】

{ai_tips}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【今日任务】
□ 检查外卖数据
□ 查看昨日营收
□ 跟进供应商

加油！💪'''
print(msg)
